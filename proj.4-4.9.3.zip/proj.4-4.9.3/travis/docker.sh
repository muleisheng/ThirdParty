#!/bin/bash

# proj.4 image has all of the Sphinx
# dependencies need to build proj.4's docs

docker pull osgeo/proj.4


